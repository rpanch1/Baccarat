import java.util.ArrayList;
import java.util.Collections;

public class BaccaratDealer {
	ArrayList<Card> deck;
	
	public void generateDeck() {
		deck = new ArrayList<Card>();
		int i,j;
		for(i=1; i<5; i++) {
			for(j=1; j<14; j++) {
				if(i == 1) {
					deck.add(new Card("Hearts", j));
				}
				else if(i == 2) {
					deck.add(new Card("Spades", j));
				}
				else if(i == 3) {
					deck.add(new Card("Diamonds", j));
				}
				else if(i == 4) {
					deck.add(new Card("Clubs", j));
				}
			}
		}
	}
	
	public ArrayList<Card> dealHand(){
		ArrayList<Card> hand = new ArrayList<Card>();
		hand.add(deck.remove(0));
		hand.add(deck.remove(0));
		return hand;
	}
	
	public Card drawOne() {
		return deck.remove(0);
	}
	
	public void shuffleDeck() {
		Collections.shuffle(deck);
	}
	
	public int deckSize() {
		return deck.size();
	}
	
	
}
