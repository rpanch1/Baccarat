import java.util.ArrayList;

public class BaccaratGameLogic {
	
	// first parameter is Player hand, second one is Banker hand
	public String whoWon(ArrayList<Card> hand1, ArrayList<Card> hand2) {
		if(handTotal(hand1) > handTotal(hand2)) {
			return "Player";
		}
		else if(handTotal(hand1) < handTotal(hand2)) {
			return "Banker";
		}
		else {
			return "Draw";
		}
	}
	
	public int handTotal(ArrayList<Card> hand) {
		int points = 0;
		for(Card C : hand) {
			if (C.value < 10) {
				points = points + C.value;
			}
		}
		while (points > 9) {
			points = points - 10;
		}
		return points;
	}
	
	public boolean evaluateBankerDraw(ArrayList<Card> hand, Card playerCard) {
		if(handTotal(hand) > 6) {
			return false;
		}
		else if(handTotal(hand) < 3) {
			return true;
		}
		else if(playerCard == null && handTotal(hand) < 6) {
			return true;
		}
		else if(playerCard.value > 9 && handTotal(hand) < 4) {
			return true;
		}
		else if(playerCard.value == 1 && handTotal(hand) < 4) {
			return true;
		}
		else if( (playerCard.value == 2 ||  playerCard.value == 3) && handTotal(hand) < 5) {
			return true;
		}
		else if( (playerCard.value == 4 ||  playerCard.value == 5) && handTotal(hand) < 6) {
			return true;
		}
		else if( (playerCard.value == 6 ||  playerCard.value == 7) && handTotal(hand) < 7) {
			return true;
		}
		else if( playerCard.value == 8 && handTotal(hand) < 3) {
			return true;
		}
		else if( playerCard.value == 9 && handTotal(hand) < 4) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean evaluatePlayerDraw(ArrayList<Card> hand) {
		if(handTotal(hand) > 5) {
			return false;
		}
		else {
			return true;
		}
	}
	
	
}
