
public class Card {
	String suite;
	int value;
	
	// constructor
	Card(String theSuite, int theValue){
		this.suite = theSuite;
		this.value = theValue;
	}
}
