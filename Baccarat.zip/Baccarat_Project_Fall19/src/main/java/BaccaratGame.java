import java.util.ArrayList;
import java.util.HashMap;
import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.util.Duration;

public class BaccaratGame extends Application {
	
	ArrayList<Card> playerHand;
	ArrayList<Card> bankerHand;
	BaccaratGameLogic gameLogic;
	double currentBet;
	double totalWinnings;
	BaccaratDealer bd;
	
	HashMap<String, Scene> sceneMap; // hash map to store different scenes
	String bidon; 					// variable to store who the user bid on
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		
		sceneMap = new HashMap<String, Scene>();        
		sceneMap.put("playScene", playScene(primaryStage));
		sceneMap.put("gameScene", gameScene(primaryStage));
		
		bd = new BaccaratDealer();
		gameLogic = new BaccaratGameLogic();
		bd.generateDeck();
		bd.shuffleDeck();
		
		primaryStage.setTitle("Baccarat");
		primaryStage.setScene(playScene(primaryStage));
		primaryStage.show();	
	}
	
	// Game introduction scene
	public Scene playScene(Stage primaryStage) {
		
		// pause transition
		PauseTransition pause = new PauseTransition(Duration.seconds(0.1));
		pause.setOnFinished(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent action) {
				primaryStage.setScene(sceneMap.get("gameScene"));
				totalWinnings = 0;
				
			}
		});

		Button playbtn= new Button("PLAY");
		playbtn.setOnAction(e->pause.play()); 
		playbtn.setPrefSize(125, 75);
		playbtn.setStyle("-fx-text-fill: crimson; "
							+ "-fx-font-weight: bold; -fx-border-color: black; "
							+ "-fx-border-width: 3; -fx-font-size: 20");
		
		Image baccarat = new Image("baccarat.jpg", 500, 500, false, false);
		ImageView title = new ImageView(baccarat);
		
		BorderPane playLayout = new BorderPane();
		
		playLayout.setBottom(playbtn);
		playLayout.setCenter(title);
		BorderPane.setMargin(playbtn, new Insets(0,0,250,0));
		BorderPane.setAlignment(playbtn, Pos.BOTTOM_CENTER);
		playLayout.setStyle("-fx-background-color: white;");
		
		return new Scene(playLayout, 1200, 1000);
	}
	
	
	
	// Game playing scene
	public Scene gameScene(Stage primaryStage) {
		
		// for displaying results for that round of play
		Label showresults = new Label("");
		
		// style show result label
		showresults.setStyle("-fx-font-size: 28;" + "-fx-font-weight: bold;"
							+ "-fx-text-fill: crimson;");
		
		// Option Menu stuff
        MenuBar menu = new MenuBar();
		Menu option = new Menu("Options");
		MenuItem freshstart = new MenuItem("Fresh Start");
		MenuItem exit = new MenuItem("Exit");
		exit.setOnAction(e-> Platform.exit());
		option.getItems().addAll(freshstart, exit);
		menu.getMenus().addAll(option);
		
		// bid text
		TextField bidtext = new TextField();
		bidtext.setText("$ bid amount");
		
		// show earnings
		Label earnings = new Label("TOTAL EARNINGS:\n$"+ totalWinnings);
		
		// bid buttons
		Button startround = new Button("START ROUND");
		Button playerbid = new Button("PLAYER");
		Button bankerbid = new Button("BANKER");
		Button drawbid = new Button("DRAW");
		
		// disable all buttons except start at the start
		playerbid.setDisable(true);
		bankerbid.setDisable(true);
		drawbid.setDisable(true);
		bidtext.setDisable(true);
		
		// style the menu / menu items / menu buttons
		option.setStyle("-fx-background-color: floralwhite;" +
						"-fx-font-weight: bold;");
		menu.setStyle("-fx-background-color: crimson;");
		menu.setPrefSize(75, 20);
		startround.setPrefSize(175, 75);
		startround.setStyle("-fx-font-weight: bold;" + "-fx-border-width: 3;" + 
							"-fx-border-color: floralwhite;" + "-fx-font-size: 18;");
		bidtext.setPrefSize(10, 40);
		playerbid.setPrefSize(135, 60);
		playerbid.setStyle("-fx-font-weight: bold;" + "-fx-border-width: 3;" + 
							"-fx-border-color: floralwhite;");
		bankerbid.setPrefSize(135, 60);
		bankerbid.setStyle("-fx-font-weight: bold;" + "-fx-border-width: 3;" + 
							"-fx-border-color: floralwhite;");
		drawbid.setPrefSize(135, 60);
		drawbid.setStyle("-fx-font-weight: bold;" + "-fx-border-width: 3;" + 
							"-fx-border-color: floralwhite;");
		earnings.setStyle("-fx-text-fill: floralwhite;" + "-fx-font-size: 20;" +
							"-fx-font-weight: bold;");
		
		// player and banker label
		Label playerlabel = new Label("PLAYER");
		Label bankerlabel = new Label("BANKER");
		
		// style the player and banker label
		playerlabel.setStyle("-fx-font-size: 30;" + "-fx-font-weight: bold;");
		bankerlabel.setStyle("-fx-font-size: 30;" + "-fx-font-weight: bold;");
		
		// box for player cards
		ImageView pcard1 = new ImageView(new Image("red_back.png", 110, 170, false, false));
		ImageView pcard2 = new ImageView(new Image("red_back.png", 110, 170, false, false));
		ImageView pcard3 = new ImageView(new Image("gray_back.png", 110, 170, false, false));
		VBox playerbox = new VBox(10, playerlabel, pcard1, pcard2, pcard3);
		
		// style player box
		playerbox.setPrefSize(475, 700);
		playerbox.setAlignment(Pos.CENTER);
		VBox.setMargin(playerlabel, new Insets(0,0,50,0));
		playerbox.setStyle("-fx-background-color: floralwhite;");
		
		// box for banker cards
		ImageView bcard1 = new ImageView(new Image("red_back.png", 110, 170, false, false));
		ImageView bcard2 = new ImageView(new Image("red_back.png", 110, 170, false, false));
		ImageView bcard3 = new ImageView(new Image("gray_back.png", 110, 170, false, false));
		VBox bankerbox = new VBox(10, bankerlabel, bcard1, bcard2, bcard3);
		
		// style banker box
		bankerbox.setPrefSize(475, 700);
		bankerbox.setAlignment(Pos.CENTER);
		VBox.setMargin(bankerlabel, new Insets(0,0,50,0));
		bankerbox.setStyle("-fx-background-color: floralwhite");
		
		// fresh start handler
		freshstart.setOnAction(e-> { 
			primaryStage.setScene(sceneMap.get("playScene")); 
			totalWinnings = 0;
			earnings.setText("TOTAL EARNINGS:\n$"+ totalWinnings);
			playerbid.setDisable(true);
			bankerbid.setDisable(true);
			drawbid.setDisable(true);
			startround.setDisable(false);
			bidtext.setText("$ bid amount");
			pcard1.setImage(new Image("red_back.png", 110, 170, false, false));
    		bcard1.setImage(new Image("red_back.png", 110, 170, false, false));
    		pcard2.setImage(new Image("red_back.png", 110, 170, false, false));
    		bcard2.setImage(new Image("red_back.png", 110, 170, false, false));
    		bcard3.setImage(new Image("gray_back.png", 110, 170, false, false));
    		pcard3.setImage(new Image("gray_back.png", 110, 170, false, false));
    		showresults.setText("");
			
		});
		
		// Action Handler for start button
		startround.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent action) {
				
				playerbid.setDisable(false);
				bankerbid.setDisable(false);
				drawbid.setDisable(false);
				bidtext.setDisable(false);
				startround.setDisable(true);
				bidtext.setText("$ bid amount");
				showresults.setText("");
				pcard1.setImage(new Image("red_back.png", 110, 170, false, false));
				pcard2.setImage(new Image("red_back.png", 110, 170, false, false));
				pcard3.setImage(new Image("gray_back.png", 110, 170, false, false));
				bcard1.setImage(new Image("red_back.png", 110, 170, false, false));
				bcard2.setImage(new Image("red_back.png", 110, 170, false, false));
				bcard3.setImage(new Image("gray_back.png", 110, 170, false, false));
				
			}
		});
		
		// pause transitions for displaying cards and deciding the winner
		// this is where all the game logic decisions will happen
		PauseTransition pause8 = new PauseTransition(Duration.seconds(1.0));
		pause8.setOnFinished(e-> { 
			
			String wonorlost = "";
			
			if(gameLogic.whoWon(playerHand, bankerHand) == bidon) {
				double amountwon;
				if(bidon == "Player") {
					amountwon = currentBet;
					wonorlost = "Congrats, you bet " + bidon + "! You win!\nYou won $" + amountwon;
					totalWinnings = totalWinnings + amountwon;
					earnings.setText("TOTAL EARNINGS:\n$"+ Double.toString((int)totalWinnings));
					startround.setDisable(false);
				}
				else if(bidon == "Banker") {
					amountwon = (int)(0.95*currentBet);
					int commission = (int)(0.05*currentBet) + 1;
					wonorlost = "Congrats, you bet " + bidon + "! You win!\n" + "Banker commission fee: $" + commission  + "\nYou won $" + amountwon;
					totalWinnings = totalWinnings + amountwon;
					earnings.setText("TOTAL EARNINGS:\n$"+ Double.toString((int)totalWinnings));
					startround.setDisable(false);
				}
				else {
					amountwon = (int)(8*currentBet);
					wonorlost = "Congrats, you bet " + bidon + "! You win!\nYou won $" + amountwon;
					totalWinnings = totalWinnings + amountwon;
					earnings.setText("TOTAL EARNINGS:\n$"+ Double.toString((int)totalWinnings));
					startround.setDisable(false);
				}
				
			}
			else {
				wonorlost = "Sorry, you bet " + bidon + "! You lose the bet!\nYou lost $" + currentBet;
				totalWinnings = totalWinnings - currentBet;
				earnings.setText("TOTAL EARNINGS:\n$"+ Double.toString((int)totalWinnings));
				startround.setDisable(false);
				
			}
			showresults.setText("Player total: " + gameLogic.handTotal(playerHand) + "\nBanker total: " 
								+ gameLogic.handTotal(bankerHand) + "\n" +gameLogic.whoWon(playerHand, bankerHand) + " wins\n"
								+ wonorlost);
			
		});
		
		PauseTransition pause7 = new PauseTransition(Duration.seconds(1.5));
		pause7.setOnFinished(e-> { 
			bcard3.setImage(new Image(Integer.toString(bankerHand.get(2).value) + bankerHand.get(2).suite + ".png", 110, 170, false, false));
			pause8.play();
		});
		
		PauseTransition pause6 = new PauseTransition(Duration.seconds(1.5));
		pause6.setOnFinished(e-> { 
			if(playerHand.size() == 3) {
				pcard3.setImage(new Image(Integer.toString(playerHand.get(2).value) + playerHand.get(2).suite + ".png", 110, 170, false, false));
			}
			if(bankerHand.size() == 3) {
				pause7.play();
			}
			else {
				pause8.play();
			}
		});
		
		PauseTransition pause5 = new PauseTransition(Duration.seconds(1.0));
		pause5.setOnFinished(e-> { 
			if(playerHand.size() == 3) {
				pcard3.setImage(new Image("red_back.png", 110, 170, false, false));
			}
			if(bankerHand.size() == 3) {
				bcard3.setImage(new Image("red_back.png", 110, 170, false, false));
			}
			pause6.play();
		});
		
		PauseTransition pause4 = new PauseTransition(Duration.seconds(0.1));
		pause4.setOnFinished(e-> { 
			int ptotal = gameLogic.handTotal(playerHand);
			int btotal = gameLogic.handTotal(bankerHand);
			if(ptotal == 8 || ptotal == 9 || btotal == 8 || btotal == 9) {
				
			}
			else if(gameLogic.evaluatePlayerDraw(playerHand) == true) {
				playerHand.add(bd.drawOne());
				if(gameLogic.evaluateBankerDraw(bankerHand, playerHand.get(2)) == true) {
					bankerHand.add(bd.drawOne());
				}
			}
			else {
				if(gameLogic.evaluateBankerDraw(bankerHand, null) == true) {
					bankerHand.add(bd.drawOne());
				}
			}
			pause5.play();
		});
		
		PauseTransition pause3 = new PauseTransition(Duration.seconds(1.5));
		pause3.setOnFinished(e-> { 
				bcard2.setImage(new Image(Integer.toString(bankerHand.get(1).value) + bankerHand.get(1).suite + ".png", 110, 170, false, false));
				pause4.play();
		});
		
		PauseTransition pause2 = new PauseTransition(Duration.seconds(1.5));
		pause2.setOnFinished(e-> {
				pcard2.setImage(new Image(Integer.toString(playerHand.get(1).value) + playerHand.get(1).suite + ".png", 110, 170, false, false));
				pause3.play();
		});
		
		PauseTransition pause1 = new PauseTransition(Duration.seconds(1.5));
		pause1.setOnFinished(e-> { 
				bcard1.setImage(new Image(Integer.toString(bankerHand.get(0).value) + bankerHand.get(0).suite + ".png", 110, 170, false, false));
				pause2.play(); 
		
		});
		
		PauseTransition pause = new PauseTransition(Duration.seconds(1.5));
		pause.setOnFinished(e-> { 
				pcard1.setImage(new Image(Integer.toString(playerHand.get(0).value) + playerHand.get(0).suite + ".png", 110, 170, false, false));
				pause1.play(); 
		
		});
		
		// player bid handler
		EventHandler<ActionEvent> playerbidhandler = new EventHandler<ActionEvent>() {
			public void handle(ActionEvent action) {
				try
				{
					Double.parseDouble(bidtext.getText());
					
					if(Double.parseDouble(bidtext.getText()) < 0) {
						bidtext.setText("invalid bid! try again!");
					}
					else{
						// update currentBet variable
						currentBet = Double.parseDouble(bidtext.getText());
						
						// disable all buttons
						startround.setDisable(true);
						playerbid.setDisable(true);
						bankerbid.setDisable(true);
						drawbid.setDisable(true);
						bidtext.setDisable(true);
						
						// draw 2 cards for player and banker
						if(bd.deckSize() < 5) {
							bd.generateDeck();
							bd.shuffleDeck();
						}
			
						playerHand = bd.dealHand();
						bankerHand = bd.dealHand();
						
						bidon = "Player";
						
						// display the cards
						
						pause.play();
						
					}
				}
				catch(NumberFormatException e)
				{
					bidtext.setText("invalid bid! try again!");
				}
			}
		};
		
		// banker bid handler
		EventHandler<ActionEvent> bankerbidhandler = new EventHandler<ActionEvent>() {
			public void handle(ActionEvent action) {
				try
				{
					Double.parseDouble(bidtext.getText());
					
					if(Double.parseDouble(bidtext.getText()) < 0) {
						bidtext.setText("invalid bid! try again!");
					}
					else{
						// update currentBet variable
						currentBet = Double.parseDouble(bidtext.getText());
						
						// disable all buttons
						startround.setDisable(true);
						playerbid.setDisable(true);
						bankerbid.setDisable(true);
						drawbid.setDisable(true);
						bidtext.setDisable(true);
						
						// draw 2 cards for player and banker
						if(bd.deckSize() < 5) {
							bd.generateDeck();
							bd.shuffleDeck();
						}
						
						playerHand = bd.dealHand();
						bankerHand = bd.dealHand();
						
						bidon = "Banker";
						
						// display the cards
						pause.play();
						
					}
				}
				catch(NumberFormatException e)
				{
					bidtext.setText("invalid bid! try again!");
				}
			}
		};
		
		// draw bid handler
		EventHandler<ActionEvent> drawbidhandler = new EventHandler<ActionEvent>() {
			public void handle(ActionEvent action) {
				
				try
				{
					Double.parseDouble(bidtext.getText());
					
					if(Double.parseDouble(bidtext.getText()) < 0) {
						bidtext.setText("invalid bid! try again!");
					}
					else{
						// update currentBet variable
						currentBet = Double.parseDouble(bidtext.getText());
						
						// disable all buttons
						startround.setDisable(true);
						playerbid.setDisable(true);
						bankerbid.setDisable(true);
						drawbid.setDisable(true);
						bidtext.setDisable(true);
						
						// draw 2 cards for player and banker
						if(bd.deckSize() < 5) {
							bd.generateDeck();
							bd.shuffleDeck();
						}
						playerHand = bd.dealHand();
						bankerHand = bd.dealHand();
						
						bidon = "Draw";
						
						// display the cards
						pause.play();
						
					}
				}
				catch(NumberFormatException e)
				{
					bidtext.setText("invalid bid! try again!");
				}
			}
		};
		
		playerbid.setOnAction(playerbidhandler);
		bankerbid.setOnAction(bankerbidhandler);
		drawbid.setOnAction(drawbidhandler);
		
		// box to display both player and banker cards
		HBox cardBox = new HBox(playerbox, bankerbox);
		cardBox.setAlignment(Pos.CENTER);
		cardBox.setPrefSize(950, 700);
	
		
		VBox result = new VBox(showresults);
		result.setPrefSize(950, 300);
		result.setAlignment(Pos.CENTER);
		result.setStyle("-fx-background-color: floralwhite");
		
		
		VBox right = new VBox(10, menu, startround, bidtext, playerbid, bankerbid, drawbid, earnings);
		VBox.setMargin(menu, new Insets(0 ,0 , 100 ,0));
		VBox.setMargin(startround, new Insets(0 ,0 , 0 ,0));
		VBox.setMargin(bidtext, new Insets(40 ,0 , 0 ,0));
		VBox.setMargin(playerbid, new Insets(35 ,0 , 0 ,0));
		VBox.setMargin(bankerbid, new Insets(25 ,0 , 0 ,0));
		VBox.setMargin(drawbid, new Insets(25 ,0 , 0 ,0));
		VBox.setMargin(earnings, new Insets(50 ,0 , 300 ,0));
		right.setAlignment(Pos.CENTER);
		right.setPrefSize(250, 1000);
		right.setStyle("-fx-background-color: crimson");
		
		VBox center = new VBox(cardBox, result);
		center.setPrefSize(950, 1000);
		center.setBackground(new Background(new BackgroundFill(Color.FLORALWHITE, CornerRadii.EMPTY, Insets.EMPTY)));
		
		BorderPane gameLayout = new BorderPane();
		gameLayout.setRight(right);
		gameLayout.setCenter(center);
		
		return new Scene(gameLayout, 1200, 1000);
	}

}

