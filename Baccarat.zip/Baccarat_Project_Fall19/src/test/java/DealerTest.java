import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DealerTest {
	
	Card card;
	BaccaratDealer dealer;
	BaccaratGameLogic gamelogic;

	@BeforeEach
	void init () {
		card = new Card("Hearts", 1);
		dealer = new BaccaratDealer();
		gamelogic = new BaccaratGameLogic();
	}
	
	@Test
	void ClassCardConstructor() {
		assertEquals("Hearts", card.suite, "Error in Card constructor. Incorrect suite.");
		assertEquals(1, card.value, "Error in Card constructor. Incorrect value.");
	}
	
	@Test
	void BaccaratDealerConstructor() {
		assertNotEquals(null, dealer, "Error when creating an instance of BaccaratDealer");
	}
	
	@Test
	void GenerateDeckTestOne() {
		dealer.generateDeck();
		assertEquals("13Clubs", dealer.deck.get(51).value + dealer.deck.get(51).suite, "Error in generate deck method");
	}
	
	@Test
	void GenerateDeckTestTwo() {
		dealer.generateDeck();
		assertEquals("1Hearts", dealer.deck.get(0).value + dealer.deck.get(0).suite, "Error in generate deck method");
	}
	
	@Test
	void DealHandTestOne() {
		dealer.generateDeck();
		ArrayList<Card> hand = dealer.dealHand();	
		assertEquals(2, hand.size(), "Error in deal hand method");
	}
	
	@Test
	void DealHandTestTwo() {
		dealer.generateDeck();
		ArrayList<Card> hand = dealer.dealHand();	
		assertNotEquals(1, hand.size(), "Error in deal hand method");
	}
	
	@Test
	void DrawOneTestOne() {
		dealer.generateDeck();
		card = dealer.drawOne();
		assertNotEquals(" ", card.suite, "Error in Draw one method. Incorrect suite.");
	}
	
	@Test
	void DrawOneTestTwo() {
		dealer.generateDeck();
		card = dealer.drawOne();
		assertNotEquals(15, card.value, "Error in Draw one method. Incorrect value.");
	}
	
	@Test
	void ShuffleDeckTestOne(){
		dealer.generateDeck();
		dealer.shuffleDeck();
		assertNotEquals("1Hearts", dealer.deck.get(0).value + dealer.deck.get(0).suite, "Error in shuffle deck method");
	}
	
	@Test
	void ShuffleDeckTestTwo(){
		dealer.generateDeck();
		dealer.shuffleDeck();
		assertNotEquals("13Clubs", dealer.deck.get(51).value + dealer.deck.get(51).suite, "Error in shuffle deck method");
	}
	
	@Test
	void DeckSizeTestOne() {
		dealer.generateDeck();
		assertEquals(52, dealer.deckSize(), "Incorrect deck size");
	}
	
	@Test
	void DeckSizeTestTwo() {
		dealer.generateDeck();
		assertNotEquals(53, dealer.deckSize(), "Incorrect deck size");
	}
	
	@Test
	void BaccaratGameLogicConstructor() {
		assertNotEquals(null, gamelogic, "Error when creating an instance of BaccaratGameLogic");
	}
	
	@Test
	void WhoWonTestOne() {
		dealer.generateDeck();
		dealer.shuffleDeck();
		ArrayList<Card> Player = dealer.dealHand();
		ArrayList<Card> Banker = dealer.dealHand();
		String s = "";
		if(gamelogic.handTotal(Player) > gamelogic.handTotal(Banker)) {
			s = "Player";
		}
		else if (gamelogic.handTotal(Player) < gamelogic.handTotal(Banker)) {
			s = "Banker";
		}
		else {
			s = "Draw";
		}
		assertEquals(s, gamelogic.whoWon(Player, Banker), "Incorrect Who Won method result");
	}
	
	@Test
	void WhoWonTestTwo() {
		dealer.generateDeck();
		dealer.shuffleDeck();
		ArrayList<Card> Player = dealer.dealHand();
		ArrayList<Card> Banker = Player;
		assertEquals("Draw", gamelogic.whoWon(Player, Banker), "Incorrect Who Won method result");
	}
	
	@Test
	void HandTotalTestOne() {
		dealer.generateDeck();
		dealer.shuffleDeck();
		ArrayList<Card> hand = dealer.dealHand();
		int n = 0;
		for(Card C : hand) {
			if(C.value < 10) {
				n += C.value;
			}
		}
		while(n > 9) {
			n -= 10;
		}
		assertEquals(n, gamelogic.handTotal(hand), "Incorrect Hand Total method result");
	}
	
	@Test
	void HandTotalTestTwo() {
		dealer.generateDeck();
		dealer.shuffleDeck();
		ArrayList<Card> hand = dealer.dealHand();
		assertNotEquals(10, gamelogic.handTotal(hand), "Incorrect Hand Total method result");
	}
	
	@Test
	void EvaluateBankerDrawTestOne() {
		dealer.generateDeck();
		dealer.shuffleDeck();
		ArrayList<Card> hand = dealer.dealHand();
		int n = gamelogic.handTotal(hand);
		boolean b;
		if(n > 6) {
			b = false;
		}
		else if(n < 3) {
			b = true;
		}
		else if(n < 6) {
			b = true;
		}
		else {
			b = false;
		}
		assertEquals(b, gamelogic.evaluateBankerDraw(hand, null), "Error in Evaluate Banker Draw method");	
	}
	
	@Test
	void EvaluateBankerDrawTestTwo() {
		dealer.generateDeck();
		dealer.shuffleDeck();
		ArrayList<Card> hand = dealer.dealHand();
		int n = gamelogic.handTotal(hand);
		boolean b;
		if(n > 6) {
			b = false;
		}
		else if(n < 3) {
			b = true;
		}
		else if(n < 4) {
			b = true;
		}
		else {
			b = false;
		}
		assertEquals(b, gamelogic.evaluateBankerDraw(hand, card), "Error in Evaluate Banker Draw method");	
	}
	
	@Test
	void EvaluatePlayerDrawTestOne() {
		dealer.generateDeck();
		dealer.shuffleDeck();
		ArrayList<Card> hand = dealer.dealHand();
		hand = new ArrayList<Card>();
		hand.add(card);
		hand.add(card);
		assertEquals(true, gamelogic.evaluatePlayerDraw(hand), "Error in Evaluate Player Draw method");	
	}
	
	@Test
	void EvaluatePlayerDrawTestTwo() {
		dealer.generateDeck();
		dealer.shuffleDeck();
		ArrayList<Card> hand = dealer.dealHand();
		hand = new ArrayList<Card>();
		card.value = 6;
		hand.add(card);
		assertEquals(false, gamelogic.evaluatePlayerDraw(hand), "Error in Evaluate Player Draw method");	
	}
	
}
